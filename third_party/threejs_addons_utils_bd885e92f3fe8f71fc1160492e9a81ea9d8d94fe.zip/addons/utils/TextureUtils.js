import{PlaneGeometry,ShaderMaterial,Uniform,Mesh,PerspectiveCamera,Scene,WebGLRenderer,CanvasTexture,SRGBColorSpace}from"three";let _renderer,fullscreenQuadGeometry,fullscreenQuadMaterial,fullscreenQuad;function decompress(texture,maxTextureSize=1/0,renderer=null){fullscreenQuadGeometry=fullscreenQuadGeometry||new PlaneGeometry(2,2,1,1),(fullscreenQuadMaterial=fullscreenQuadMaterial||new ShaderMaterial({uniforms:{blitTexture:new Uniform(texture)},vertexShader:`
			varying vec2 vUv;
			void main(){
				vUv = uv;
				gl_Position = vec4(position.xy * 1.0,0.,.999999);
			}`,fragmentShader:`
			uniform sampler2D blitTexture; 
			varying vec2 vUv;

			void main(){ 
				gl_FragColor = vec4(vUv.xy, 0, 1);
				
				#ifdef IS_SRGB
				gl_FragColor = LinearTosRGB( texture2D( blitTexture, vUv) );
				#else
				gl_FragColor = texture2D( blitTexture, vUv);
				#endif
			}`})).uniforms.blitTexture.value=texture,fullscreenQuadMaterial.defines.IS_SRGB=texture.colorSpace==SRGBColorSpace,fullscreenQuadMaterial.needsUpdate=!0,fullscreenQuad||((fullscreenQuad=new Mesh(fullscreenQuadGeometry,fullscreenQuadMaterial)).frustrumCulled=!1);var _camera=new PerspectiveCamera,_scene=new Scene,width=(_scene.add(fullscreenQuad),null===renderer&&(renderer=_renderer=new WebGLRenderer({antialias:!1})),Math.min(texture.image.width,maxTextureSize)),maxTextureSize=Math.min(texture.image.height,maxTextureSize),_scene=(renderer.setSize(width,maxTextureSize),renderer.clear(),renderer.render(_scene,_camera),document.createElement("canvas")),_camera=_scene.getContext("2d"),_camera=(_scene.width=width,_scene.height=maxTextureSize,_camera.drawImage(renderer.domElement,0,0,width,maxTextureSize),new CanvasTexture(_scene));return _camera.minFilter=texture.minFilter,_camera.magFilter=texture.magFilter,_camera.wrapS=texture.wrapS,_camera.wrapT=texture.wrapT,_camera.name=texture.name,_renderer&&(_renderer.forceContextLoss(),_renderer.dispose(),_renderer=null),_camera}export{decompress};