export default`
gl_FragColor = linearToOutputTexel( gl_FragColor );
`;