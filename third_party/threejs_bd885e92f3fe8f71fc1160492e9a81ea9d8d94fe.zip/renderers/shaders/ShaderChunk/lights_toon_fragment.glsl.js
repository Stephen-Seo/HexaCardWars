export default`
ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;
`;