export default`
#ifdef USE_METALNESSMAP

	uniform sampler2D metalnessMap;

#endif
`;