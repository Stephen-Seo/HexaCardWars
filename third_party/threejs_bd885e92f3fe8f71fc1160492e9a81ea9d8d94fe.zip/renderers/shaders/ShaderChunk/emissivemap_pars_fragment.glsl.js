export default`
#ifdef USE_EMISSIVEMAP

	uniform sampler2D emissiveMap;

#endif
`;