export default`
#ifdef USE_FOG

	varying float vFogDepth;

#endif
`;