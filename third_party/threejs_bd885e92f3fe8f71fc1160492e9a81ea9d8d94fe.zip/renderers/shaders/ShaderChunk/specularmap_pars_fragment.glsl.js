export default`
#ifdef USE_SPECULARMAP

	uniform sampler2D specularMap;

#endif
`;