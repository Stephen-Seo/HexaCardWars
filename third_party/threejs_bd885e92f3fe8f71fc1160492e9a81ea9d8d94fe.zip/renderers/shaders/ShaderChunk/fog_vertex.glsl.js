export default`
#ifdef USE_FOG

	vFogDepth = - mvPosition.z;

#endif
`;