export default`
#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif
`;