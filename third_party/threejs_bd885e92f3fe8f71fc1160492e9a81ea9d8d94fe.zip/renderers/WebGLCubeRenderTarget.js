import{BackSide,LinearFilter,LinearMipmapLinearFilter,NoBlending}from"../constants.js";import{Mesh}from"../objects/Mesh.js";import{BoxGeometry}from"../geometries/BoxGeometry.js";import{ShaderMaterial}from"../materials/ShaderMaterial.js";import{cloneUniforms}from"./shaders/UniformsUtils.js";import{WebGLRenderTarget}from"./WebGLRenderTarget.js";import{CubeCamera}from"../cameras/CubeCamera.js";import{CubeTexture}from"../textures/CubeTexture.js";class WebGLCubeRenderTarget extends WebGLRenderTarget{constructor(size=1,options={}){super(size,size,options),this.isWebGLCubeRenderTarget=!0;size={width:size,height:size,depth:1};this.texture=new CubeTexture([size,size,size,size,size,size],options.mapping,options.wrapS,options.wrapT,options.magFilter,options.minFilter,options.format,options.type,options.anisotropy,options.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=void 0!==options.generateMipmaps&&options.generateMipmaps,this.texture.minFilter=void 0!==options.minFilter?options.minFilter:LinearFilter}fromEquirectangularTexture(renderer,texture){this.texture.type=texture.type,this.texture.colorSpace=texture.colorSpace,this.texture.generateMipmaps=texture.generateMipmaps,this.texture.minFilter=texture.minFilter,this.texture.magFilter=texture.magFilter;var shader={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},geometry=new BoxGeometry(5,5,5),shader=new ShaderMaterial({name:"CubemapFromEquirect",uniforms:cloneUniforms(shader.uniforms),vertexShader:shader.vertexShader,fragmentShader:shader.fragmentShader,side:BackSide,blending:NoBlending}),geometry=(shader.uniforms.tEquirect.value=texture,new Mesh(geometry,shader)),shader=texture.minFilter;return texture.minFilter===LinearMipmapLinearFilter&&(texture.minFilter=LinearFilter),new CubeCamera(1,10,this).update(renderer,geometry),texture.minFilter=shader,geometry.geometry.dispose(),geometry.material.dispose(),this}clear(renderer,color,depth,stencil){var currentRenderTarget=renderer.getRenderTarget();for(let i=0;i<6;i++)renderer.setRenderTarget(this,i),renderer.clear(color,depth,stencil);renderer.setRenderTarget(currentRenderTarget)}}export{WebGLCubeRenderTarget};