import{CubeReflectionMapping,CubeRefractionMapping,CubeUVReflectionMapping,LinearFilter,NoToneMapping,NoBlending,RGBAFormat,HalfFloatType,BackSide,LinearSRGBColorSpace}from"../constants.js";import{BufferAttribute}from"../core/BufferAttribute.js";import{BufferGeometry}from"../core/BufferGeometry.js";import{Mesh}from"../objects/Mesh.js";import{OrthographicCamera}from"../cameras/OrthographicCamera.js";import{PerspectiveCamera}from"../cameras/PerspectiveCamera.js";import{ShaderMaterial}from"../materials/ShaderMaterial.js";import{Vector3}from"../math/Vector3.js";import{Color}from"../math/Color.js";import{WebGLRenderTarget}from"../renderers/WebGLRenderTarget.js";import{MeshBasicMaterial}from"../materials/MeshBasicMaterial.js";import{BoxGeometry}from"../geometries/BoxGeometry.js";const LOD_MIN=4,EXTRA_LOD_SIGMA=[.125,.215,.35,.446,.526,.582],MAX_SAMPLES=20,_flatCamera=new OrthographicCamera,_clearColor=new Color;let _oldTarget=null,_oldActiveCubeFace=0,_oldActiveMipmapLevel=0;const PHI=(1+Math.sqrt(5))/2,INV_PHI=1/PHI,_axisDirections=[new Vector3(1,1,1),new Vector3(-1,1,1),new Vector3(1,1,-1),new Vector3(-1,1,-1),new Vector3(0,PHI,INV_PHI),new Vector3(0,PHI,-INV_PHI),new Vector3(INV_PHI,0,PHI),new Vector3(-INV_PHI,0,PHI),new Vector3(PHI,INV_PHI,0),new Vector3(-PHI,INV_PHI,0)];class PMREMGenerator{constructor(renderer){this._renderer=renderer,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(scene,sigma=0,near=.1,far=100){_oldTarget=this._renderer.getRenderTarget(),_oldActiveCubeFace=this._renderer.getActiveCubeFace(),_oldActiveMipmapLevel=this._renderer.getActiveMipmapLevel(),this._setSize(256);var cubeUVRenderTarget=this._allocateTargets();return cubeUVRenderTarget.depthBuffer=!0,this._sceneToCubeUV(scene,near,far,cubeUVRenderTarget),0<sigma&&this._blur(cubeUVRenderTarget,0,0,sigma),this._applyPMREM(cubeUVRenderTarget),this._cleanup(cubeUVRenderTarget),cubeUVRenderTarget}fromEquirectangular(equirectangular,renderTarget=null){return this._fromTexture(equirectangular,renderTarget)}fromCubemap(cubemap,renderTarget=null){return this._fromTexture(cubemap,renderTarget)}compileCubemapShader(){null===this._cubemapMaterial&&(this._cubemapMaterial=_getCubemapMaterial(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){null===this._equirectMaterial&&(this._equirectMaterial=_getEquirectMaterial(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),null!==this._cubemapMaterial&&this._cubemapMaterial.dispose(),null!==this._equirectMaterial&&this._equirectMaterial.dispose()}_setSize(cubeSize){this._lodMax=Math.floor(Math.log2(cubeSize)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){null!==this._blurMaterial&&this._blurMaterial.dispose(),null!==this._pingPongRenderTarget&&this._pingPongRenderTarget.dispose();for(let i=0;i<this._lodPlanes.length;i++)this._lodPlanes[i].dispose()}_cleanup(outputTarget){this._renderer.setRenderTarget(_oldTarget,_oldActiveCubeFace,_oldActiveMipmapLevel),outputTarget.scissorTest=!1,_setViewport(outputTarget,0,0,outputTarget.width,outputTarget.height)}_fromTexture(texture,renderTarget){texture.mapping===CubeReflectionMapping||texture.mapping===CubeRefractionMapping?this._setSize(0===texture.image.length?16:texture.image[0].width||texture.image[0].image.width):this._setSize(texture.image.width/4),_oldTarget=this._renderer.getRenderTarget(),_oldActiveCubeFace=this._renderer.getActiveCubeFace(),_oldActiveMipmapLevel=this._renderer.getActiveMipmapLevel();renderTarget=renderTarget||this._allocateTargets();return this._textureToCubeUV(texture,renderTarget),this._applyPMREM(renderTarget),this._cleanup(renderTarget),renderTarget}_allocateTargets(){var width=3*Math.max(this._cubeSize,112),height=4*this._cubeSize,params={magFilter:LinearFilter,minFilter:LinearFilter,generateMipmaps:!1,type:HalfFloatType,format:RGBAFormat,colorSpace:LinearSRGBColorSpace,depthBuffer:!1},cubeUVRenderTarget=_createRenderTarget(width,height,params);return null!==this._pingPongRenderTarget&&this._pingPongRenderTarget.width===width&&this._pingPongRenderTarget.height===height||(null!==this._pingPongRenderTarget&&this._dispose(),this._pingPongRenderTarget=_createRenderTarget(width,height,params),params=this["_lodMax"],{sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=_createPlanes(params),this._blurMaterial=_getBlurShader(params,width,height)),cubeUVRenderTarget}_compileMaterial(material){material=new Mesh(this._lodPlanes[0],material);this._renderer.compile(material,_flatCamera)}_sceneToCubeUV(scene,near,far,cubeUVRenderTarget){var cubeCamera=new PerspectiveCamera(90,1,near,far),upSign=[1,-1,1,1,1,1],forwardSign=[1,1,1,-1,-1,-1],renderer=this._renderer,near=renderer.autoClear,far=renderer.toneMapping,backgroundMaterial=(renderer.getClearColor(_clearColor),renderer.toneMapping=NoToneMapping,renderer.autoClear=!1,new MeshBasicMaterial({name:"PMREM.Background",side:BackSide,depthWrite:!1,depthTest:!1})),backgroundBox=new Mesh(new BoxGeometry,backgroundMaterial);let useSolidColor=!1;var background=scene.background;background?background.isColor&&(backgroundMaterial.color.copy(background),scene.background=null,useSolidColor=!0):(backgroundMaterial.color.copy(_clearColor),useSolidColor=!0);for(let i=0;i<6;i++){var col=i%3,size=(0==col?(cubeCamera.up.set(0,upSign[i],0),cubeCamera.lookAt(forwardSign[i],0,0)):1==col?(cubeCamera.up.set(0,0,upSign[i]),cubeCamera.lookAt(0,forwardSign[i],0)):(cubeCamera.up.set(0,upSign[i],0),cubeCamera.lookAt(0,0,forwardSign[i])),this._cubeSize);_setViewport(cubeUVRenderTarget,col*size,2<i?size:0,size,size),renderer.setRenderTarget(cubeUVRenderTarget),useSolidColor&&renderer.render(backgroundBox,cubeCamera),renderer.render(scene,cubeCamera)}backgroundBox.geometry.dispose(),backgroundBox.material.dispose(),renderer.toneMapping=far,renderer.autoClear=near,scene.background=background}_textureToCubeUV(texture,cubeUVRenderTarget){var renderer=this._renderer,isCubeTexture=texture.mapping===CubeReflectionMapping||texture.mapping===CubeRefractionMapping,isCubeTexture=(isCubeTexture?(null===this._cubemapMaterial&&(this._cubemapMaterial=_getCubemapMaterial()),this._cubemapMaterial.uniforms.flipEnvMap.value=!1===texture.isRenderTargetTexture?-1:1):null===this._equirectMaterial&&(this._equirectMaterial=_getEquirectMaterial()),isCubeTexture?this._cubemapMaterial:this._equirectMaterial),mesh=new Mesh(this._lodPlanes[0],isCubeTexture),isCubeTexture=(isCubeTexture.uniforms.envMap.value=texture,this._cubeSize);_setViewport(cubeUVRenderTarget,0,0,3*isCubeTexture,2*isCubeTexture),renderer.setRenderTarget(cubeUVRenderTarget),renderer.render(mesh,_flatCamera)}_applyPMREM(cubeUVRenderTarget){var renderer=this._renderer,autoClear=renderer.autoClear;renderer.autoClear=!1;for(let i=1;i<this._lodPlanes.length;i++){var sigma=Math.sqrt(this._sigmas[i]*this._sigmas[i]-this._sigmas[i-1]*this._sigmas[i-1]),poleAxis=_axisDirections[(i-1)%_axisDirections.length];this._blur(cubeUVRenderTarget,i-1,i,sigma,poleAxis)}renderer.autoClear=autoClear}_blur(cubeUVRenderTarget,lodIn,lodOut,sigma,poleAxis){var pingPongRenderTarget=this._pingPongRenderTarget;this._halfBlur(cubeUVRenderTarget,pingPongRenderTarget,lodIn,lodOut,sigma,"latitudinal",poleAxis),this._halfBlur(pingPongRenderTarget,cubeUVRenderTarget,lodOut,lodOut,sigma,"longitudinal",poleAxis)}_halfBlur(targetIn,targetOut,lodIn,lodOut,sigmaRadians,direction,poleAxis){var renderer=this._renderer,blurMaterial=this._blurMaterial,blurMesh=("latitudinal"!==direction&&"longitudinal"!==direction&&console.error("blur direction must be either latitudinal or longitudinal!"),new Mesh(this._lodPlanes[lodOut],blurMaterial)),blurMaterial=blurMaterial.uniforms,pixels=this._sizeLods[lodIn]-1,pixels=isFinite(sigmaRadians)?Math.PI/(2*pixels):2*Math.PI/(2*MAX_SAMPLES-1),sigmaPixels=sigmaRadians/pixels,samples=isFinite(sigmaRadians)?1+Math.floor(3*sigmaPixels):MAX_SAMPLES,weights=(samples>MAX_SAMPLES&&console.warn(`sigmaRadians, ${sigmaRadians}, is too large and will clip, as it requested ${samples} samples when the maximum is set to `+MAX_SAMPLES),[]);let sum=0;for(let i=0;i<MAX_SAMPLES;++i){const x=i/sigmaPixels;var weight=Math.exp(-x*x/2);weights.push(weight),0===i?sum+=weight:i<samples&&(sum+=2*weight)}for(let i=0;i<weights.length;i++)weights[i]=weights[i]/sum;blurMaterial.envMap.value=targetIn.texture,blurMaterial.samples.value=samples,blurMaterial.weights.value=weights,blurMaterial.latitudinal.value="latitudinal"===direction,poleAxis&&(blurMaterial.poleAxis.value=poleAxis);sigmaRadians=this._lodMax,blurMaterial.dTheta.value=pixels,blurMaterial.mipInt.value=sigmaRadians-lodIn,targetIn=this._sizeLods[lodOut];const x=3*targetIn*(lodOut>sigmaRadians-LOD_MIN?lodOut-sigmaRadians+LOD_MIN:0);direction=4*(this._cubeSize-targetIn);_setViewport(targetOut,x,direction,3*targetIn,2*targetIn),renderer.setRenderTarget(targetOut),renderer.render(blurMesh,_flatCamera)}}function _createPlanes(lodMax){var lodPlanes=[],sizeLods=[],sigmas=[];let lod=lodMax;var totalLods=lodMax-LOD_MIN+1+EXTRA_LOD_SIGMA.length;for(let i=0;i<totalLods;i++){var sizeLod=Math.pow(2,lod);sizeLods.push(sizeLod);let sigma=1/sizeLod;i>lodMax-LOD_MIN?sigma=EXTRA_LOD_SIGMA[i-lodMax+LOD_MIN-1]:0===i&&(sigma=0),sigmas.push(sigma);var sizeLod=1/(sizeLod-2),min=-sizeLod,sizeLod=1+sizeLod,uv1=[min,min,sizeLod,min,sizeLod,sizeLod,min,min,sizeLod,sizeLod,min,sizeLod],position=new Float32Array(108),uv=new Float32Array(72),faceIndex=new Float32Array(36);for(let face=0;face<6;face++){var x=face%3*2/3-1,y=2<face?0:-1,x=(position.set([x,y,0,x+2/3,y,0,x+2/3,1+y,0,x,y,0,x+2/3,1+y,0,x,1+y,0],18*face),uv.set(uv1,12*face),[face,face,face,face,face,face]);faceIndex.set(x,6*face)}min=new BufferGeometry;min.setAttribute("position",new BufferAttribute(position,3)),min.setAttribute("uv",new BufferAttribute(uv,2)),min.setAttribute("faceIndex",new BufferAttribute(faceIndex,1)),lodPlanes.push(min),lod>LOD_MIN&&lod--}return{lodPlanes:lodPlanes,sizeLods:sizeLods,sigmas:sigmas}}function _createRenderTarget(width,height,params){width=new WebGLRenderTarget(width,height,params);return width.texture.mapping=CubeUVReflectionMapping,width.texture.name="PMREM.cubeUv",width.scissorTest=!0,width}function _setViewport(target,x,y,width,height){target.viewport.set(x,y,width,height),target.scissor.set(x,y,width,height)}function _getBlurShader(lodMax,width,height){var weights=new Float32Array(MAX_SAMPLES),poleAxis=new Vector3(0,1,0);return new ShaderMaterial({name:"SphericalGaussianBlur",defines:{n:MAX_SAMPLES,CUBEUV_TEXEL_WIDTH:1/width,CUBEUV_TEXEL_HEIGHT:1/height,CUBEUV_MAX_MIP:lodMax+".0"},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:weights},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:poleAxis}},vertexShader:_getCommonVertexShader(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:NoBlending,depthTest:!1,depthWrite:!1})}function _getEquirectMaterial(){return new ShaderMaterial({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:_getCommonVertexShader(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:NoBlending,depthTest:!1,depthWrite:!1})}function _getCubemapMaterial(){return new ShaderMaterial({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:_getCommonVertexShader(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:NoBlending,depthTest:!1,depthWrite:!1})}function _getCommonVertexShader(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}export{PMREMGenerator};